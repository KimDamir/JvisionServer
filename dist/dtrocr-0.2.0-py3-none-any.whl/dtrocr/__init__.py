import os
import sys

from register_dataclasses import register_dataclasses

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
print("hello")
